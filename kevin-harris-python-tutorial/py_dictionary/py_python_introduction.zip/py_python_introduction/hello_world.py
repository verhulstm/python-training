#------------------------------------------------------------------------------
#           Name: hello_world.py
#         Author: Kevin Harris
#  Last Modified: 02/13/04
#    Description: A very simple Python script for beginners.
#------------------------------------------------------------------------------

print "Hello World!"

# The following call to raw_input is not really necessary, but with out
# something to pause the script, it will open and close the command window
# too fast for the, "Hello World!", string to be read.
raw_input( '\nPress Enter to exit...' )
